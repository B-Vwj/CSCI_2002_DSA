package testutil;

/**
 *  Zero-argument evaluation block, no return value
 *  functional interface
 */

public interface Evaluable {
	void evaluate();
}