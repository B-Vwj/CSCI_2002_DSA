
java -cp "src:test:scorerbase.jar" tests_cases._UnitTestManager

read -p "Press enter to continue"
