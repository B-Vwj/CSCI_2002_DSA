package spacesurvival;

/*
 * Inerface EnergyEventIdea
 * 
 * I am a simple interface that has a one method protocol.
 */

public interface EnergyEventIdea {
	
	/*Return the energy provided/gained (+) or consumed/lost (-)*/ 
	int getEnergy();
}