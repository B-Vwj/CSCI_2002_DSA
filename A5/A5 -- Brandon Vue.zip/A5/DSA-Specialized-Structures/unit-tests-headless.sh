
java -cp "src:test:scorerbase.jar:ss_support.jar" tests_cases._UnitTestManager

read -p "Press enter to continue"
